import asyncio
import aiohttp
import time
import statistics
from dataclasses import dataclass, field
from urllib.parse import urlparse

@dataclass
class TestConfig:
    url: str
    num_requests: int
    concurrency: int
    method: str = "GET"
    timeout: int = 10
    headers: dict = field(default_factory=dict)

@dataclass
class RequestResult:
    success: bool
    status_code: int | None
    response_time: float
    error: str | None = None
    size: int = 0

class LoadTester:
    def __init__(self, config: TestConfig):
        self.config = config
        self.results: list[RequestResult] = []
        self.start_time: float = 0
        self.completed: int = 0
    
    async def send_request(self, session: aiohttp.ClientSession) -> RequestResult:
        """Send a single request and return the result."""
        start = time.perf_counter()
        try:
            async with session.request(
                self.config.method,
                self.config.url,
                timeout=aiohttp.ClientTimeout(total=self.config.timeout),
                headers=self.config.headers
            ) as response:
                content = await response.read()
                elapsed = time.perf_counter() - start
                return RequestResult(
                    success=True,
                    status_code=response.status,
                    response_time=elapsed,
                    size=len(content)
                )
        except asyncio.TimeoutError:
            return RequestResult(False, None, time.perf_counter() - start, "Timeout")
        except aiohttp.ClientError as e:
            return RequestResult(False, None, time.perf_counter() - start, str(e))
        except Exception as e:
            return RequestResult(False, None, time.perf_counter() - start, str(e))
    
    async def worker(self, session: aiohttp.ClientSession, semaphore: asyncio.Semaphore):
        """Worker that sends requests while respecting concurrency limit."""
        async with semaphore:
            result = await self.send_request(session)
            self.results.append(result)
            self.completed += 1
            self.print_progress()
    
    def print_progress(self):
        """Print progress bar."""
        total = self.config.num_requests
        percent = (self.completed / total) * 100
        bar_length = 40
        filled = int(bar_length * self.completed / total)
        bar = "█" * filled + "░" * (bar_length - filled)
        elapsed = time.perf_counter() - self.start_time
        rps = self.completed / elapsed if elapsed > 0 else 0
        print(f"\r[{bar}] {percent:5.1f}% | {self.completed}/{total} | {rps:.1f} req/s", end="", flush=True)
    
    async def run(self):
        """Run the load test."""
        self.start_time = time.perf_counter()
        semaphore = asyncio.Semaphore(self.config.concurrency)
        
        connector = aiohttp.TCPConnector(limit=self.config.concurrency, limit_per_host=self.config.concurrency)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = [self.worker(session, semaphore) for _ in range(self.config.num_requests)]
            await asyncio.gather(*tasks)
        
        print()  # New line after progress bar
        return time.perf_counter() - self.start_time
    
    def get_statistics(self, total_time: float) -> dict:
        """Calculate comprehensive statistics."""
        successful = [r for r in self.results if r.success]
        failed = [r for r in self.results if not r.success]
        response_times = [r.response_time for r in successful]
        
        stats = {
            "total_requests": len(self.results),
            "successful": len(successful),
            "failed": len(failed),
            "success_rate": (len(successful) / len(self.results) * 100) if self.results else 0,
            "total_time": total_time,
            "requests_per_second": len(self.results) / total_time if total_time > 0 else 0,
        }
        
        if response_times:
            sorted_times = sorted(response_times)
            stats.update({
                "min_time": min(response_times),
                "max_time": max(response_times),
                "avg_time": statistics.mean(response_times),
                "median_time": statistics.median(response_times),
                "p90_time": sorted_times[int(len(sorted_times) * 0.9)] if len(sorted_times) >= 10 else None,
                "p99_time": sorted_times[int(len(sorted_times) * 0.99)] if len(sorted_times) >= 100 else None,
                "std_dev": statistics.stdev(response_times) if len(response_times) > 1 else 0,
                "total_data": sum(r.size for r in successful),
            })
        
        # Count status codes
        status_codes = {}
        for r in successful:
            status_codes[r.status_code] = status_codes.get(r.status_code, 0) + 1
        stats["status_codes"] = status_codes
        
        # Count errors
        errors = {}
        for r in failed:
            errors[r.error] = errors.get(r.error, 0) + 1
        stats["errors"] = errors
        
        return stats
    
    def print_report(self, stats: dict):
        """Print a formatted report."""
        print("\n" + "=" * 60)
        print("                      LOAD TEST REPORT")
        print("=" * 60)
        print(f"  Target URL:         {self.config.url}")
        print(f"  Method:             {self.config.method}")
        print(f"  Concurrency:        {self.config.concurrency}")
        print("-" * 60)
        print("  SUMMARY")
        print("-" * 60)
        print(f"  Total Requests:     {stats['total_requests']}")
        print(f"  Successful:         {stats['successful']}")
        print(f"  Failed:             {stats['failed']}")
        print(f"  Success Rate:       {stats['success_rate']:.1f}%")
        print(f"  Total Time:         {stats['total_time']:.2f}s")
        print(f"  Requests/sec:       {stats['requests_per_second']:.2f}")
        
        if stats.get("avg_time"):
            print("-" * 60)
            print("  RESPONSE TIMES")
            print("-" * 60)
            print(f"  Min:                {stats['min_time']*1000:.1f}ms")
            print(f"  Max:                {stats['max_time']*1000:.1f}ms")
            print(f"  Average:            {stats['avg_time']*1000:.1f}ms")
            print(f"  Median:             {stats['median_time']*1000:.1f}ms")
            if stats.get("p90_time"):
                print(f"  90th Percentile:    {stats['p90_time']*1000:.1f}ms")
            if stats.get("p99_time"):
                print(f"  99th Percentile:    {stats['p99_time']*1000:.1f}ms")
            print(f"  Std Deviation:      {stats['std_dev']*1000:.1f}ms")
            print(f"  Data Transferred:   {stats['total_data'] / 1024:.1f} KB")
        
        if stats["status_codes"]:
            print("-" * 60)
            print("  STATUS CODES")
            print("-" * 60)
            for code, count in sorted(stats["status_codes"].items()):
                print(f"  {code}:                {count}")
        
        if stats["errors"]:
            print("-" * 60)
            print("  ERRORS")
            print("-" * 60)
            for error, count in stats["errors"].items():
                print(f"  {error}: {count}")
        
        print("=" * 60)


def validate_url(url: str) -> str:
    """Validate and normalize URL."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    parsed = urlparse(url)
    if not parsed.netloc:
        raise ValueError("Invalid URL")
    return url


def get_int_input(prompt: str, default: int, min_val: int = 1, max_val: int = 10000) -> int:
    """Get integer input with validation."""
    while True:
        try:
            value = input(f"{prompt} [{default}]: ").strip()
            if not value:
                return default
            value = int(value)
            if min_val <= value <= max_val:
                return value
            print(f"Please enter a number between {min_val} and {max_val}")
        except ValueError:
            print("Please enter a valid number")


async def main():
    print("=" * 60)
    print("         ASYNC LOAD TESTER (For your own sites only!)")
    print("=" * 60)
    
    # Get configuration
    while True:
        try:
            url = input("\nEnter your website URL: ").strip()
            url = validate_url(url)
            break
        except ValueError:
            print("Please enter a valid URL")
    
    num_requests = get_int_input("Total number of requests", 100, 1, 10000)
    concurrency = get_int_input("Concurrent connections", 10, 1, 500)
    
    method = input("HTTP method (GET/POST/HEAD) [GET]: ").strip().upper() or "GET"
    if method not in ["GET", "POST", "HEAD", "PUT", "DELETE"]:
        method = "GET"
    
    timeout = get_int_input("Request timeout in seconds", 10, 1, 60)
    
    # Confirm
    print(f"\n{'─' * 60}")
    print(f"  URL:          {url}")
    print(f"  Requests:     {num_requests}")
    print(f"  Concurrency:  {concurrency}")
    print(f"  Method:       {method}")
    print(f"  Timeout:      {timeout}s")
    print(f"{'─' * 60}")
    
    confirm = input("\nStart test? (yes/no): ").strip().lower()
    if confirm != "yes":
        print("Test cancelled.")
        return
    
    print("\nRunning load test...\n")
    
    # Run test
    config = TestConfig(
        url=url,
        num_requests=num_requests,
        concurrency=concurrency,
        method=method,
        timeout=timeout
    )
    
    tester = LoadTester(config)
    total_time = await tester.run()
    stats = tester.get_statistics(total_time)
    tester.print_report(stats)


if __name__ == "__main__":
    asyncio.run(main())
