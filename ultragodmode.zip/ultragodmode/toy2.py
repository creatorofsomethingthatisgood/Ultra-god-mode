#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         ULTIMATE LOAD TESTER v2.0                            ║
║                    Professional HTTP Load Testing Tool                        ║
║                      (For testing your own sites only!)                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

Features:
- Async I/O for maximum performance
- Multiple test modes (sustained, ramp-up, spike, stress)
- Real-time live dashboard with graphs
- Comprehensive statistics (percentiles, histograms, trends)
- Multiple URL support with weights
- Custom headers, cookies, authentication
- Request body support (JSON, form data, raw)
- Response validation
- Rate limiting
- Export to JSON, CSV, HTML
- Configuration file support (YAML/JSON)
- Colored terminal output
- Graceful shutdown handling
- SSL certificate options
- Proxy support
- Session/cookie persistence
- Request/response logging
"""

import asyncio
import aiohttp
import time
import statistics
import json
import csv
import sys
import os
import signal
import random
import string
import hashlib
import base64
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, Any
from urllib.parse import urlparse, urlencode
from enum import Enum
from collections import deque
import argparse

# Terminal colors
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    RESET = '\033[0m'
    
    @classmethod
    def disable(cls):
        cls.HEADER = cls.BLUE = cls.CYAN = cls.GREEN = ''
        cls.YELLOW = cls.RED = cls.BOLD = cls.DIM = cls.RESET = ''


class TestMode(Enum):
    SUSTAINED = "sustained"      # Constant load
    RAMP_UP = "ramp_up"          # Gradually increase load
    SPIKE = "spike"              # Sudden burst of traffic
    STRESS = "stress"            # Increase until failure
    SOAK = "soak"                # Long duration test


class HttpMethod(Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


@dataclass
class RequestConfig:
    url: str
    method: HttpMethod = HttpMethod.GET
    headers: dict = field(default_factory=dict)
    body: Optional[str] = None
    json_body: Optional[dict] = None
    form_data: Optional[dict] = None
    cookies: dict = field(default_factory=dict)
    weight: float = 1.0  # For multiple URL testing
    name: str = ""  # Friendly name for reports
    
    def __post_init__(self):
        if not self.name:
            self.name = urlparse(self.url).path or "/"


@dataclass
class TestConfig:
    requests: list  # List of RequestConfig
    total_requests: int = 100
    concurrency: int = 10
    duration: Optional[int] = None  # Duration in seconds (overrides total_requests)
    mode: TestMode = TestMode.SUSTAINED
    ramp_up_time: int = 10  # Seconds to ramp up
    ramp_up_steps: int = 5  # Number of steps in ramp up
    rate_limit: Optional[float] = None  # Requests per second limit
    timeout: int = 30
    verify_ssl: bool = True
    proxy: Optional[str] = None
    follow_redirects: bool = True
    max_redirects: int = 10
    warm_up_requests: int = 0
    think_time: tuple = (0, 0)  # Min/max delay between requests (seconds)
    validation: dict = field(default_factory=dict)  # Response validation rules
    save_responses: bool = False
    verbose: bool = False


@dataclass
class RequestResult:
    url: str
    method: str
    success: bool
    status_code: Optional[int]
    response_time: float
    timestamp: float
    size: int = 0
    error: Optional[str] = None
    response_body: Optional[str] = None
    response_headers: Optional[dict] = None
    validation_passed: bool = True
    validation_errors: list = field(default_factory=list)
    dns_time: float = 0
    connect_time: float = 0
    ttfb: float = 0  # Time to first byte


@dataclass
class TimeSeriesData:
    timestamp: float
    requests_completed: int
    successful: int
    failed: int
    rps: float
    avg_response_time: float
    active_connections: int
    error_rate: float


class ResponseValidator:
    """Validate responses against rules."""
    
    @staticmethod
    def validate(result: RequestResult, rules: dict) -> tuple[bool, list]:
        errors = []
        
        if not result.success:
            return False, ["Request failed"]
        
        # Status code validation
        if "status_codes" in rules:
            if result.status_code not in rules["status_codes"]:
                errors.append(f"Status {result.status_code} not in {rules['status_codes']}")
        
        # Response time validation
        if "max_response_time" in rules:
            if result.response_time > rules["max_response_time"]:
                errors.append(f"Response time {result.response_time:.2f}s > {rules['max_response_time']}s")
        
        # Body contains validation
        if "body_contains" in rules and result.response_body:
            for text in rules["body_contains"]:
                if text not in result.response_body:
                    errors.append(f"Response body missing: '{text}'")
        
        # Body not contains validation
        if "body_not_contains" in rules and result.response_body:
            for text in rules["body_not_contains"]:
                if text in result.response_body:
                    errors.append(f"Response body contains forbidden: '{text}'")
        
        # Minimum size validation
        if "min_size" in rules:
            if result.size < rules["min_size"]:
                errors.append(f"Response size {result.size} < {rules['min_size']}")
        
        # Header validation
        if "headers_present" in rules and result.response_headers:
            for header in rules["headers_present"]:
                if header.lower() not in [h.lower() for h in result.response_headers]:
                    errors.append(f"Missing header: {header}")
        
        return len(errors) == 0, errors


class LiveDashboard:
    """Real-time terminal dashboard."""
    
    def __init__(self, config: TestConfig):
        self.config = config
        self.start_time = time.time()
        self.results: deque = deque(maxlen=1000)
        self.time_series: list[TimeSeriesData] = []
        self.completed = 0
        self.successful = 0
        self.failed = 0
        self.active_connections = 0
        self.last_update = 0
        self.response_times: deque = deque(maxlen=500)
        self.rps_history: deque = deque(maxlen=60)
        self.status_codes: dict = {}
        self.errors: dict = {}
        self.url_stats: dict = {}
        self.running = True
        
    def add_result(self, result: RequestResult):
        self.results.append(result)
        self.completed += 1
        self.response_times.append(result.response_time)
        
        if result.success:
            self.successful += 1
            self.status_codes[result.status_code] = self.status_codes.get(result.status_code, 0) + 1
        else:
            self.failed += 1
            self.errors[result.error or "Unknown"] = self.errors.get(result.error or "Unknown", 0) + 1
        
        # Track per-URL stats
        if result.url not in self.url_stats:
            self.url_stats[result.url] = {"success": 0, "failed": 0, "times": []}
        if result.success:
            self.url_stats[result.url]["success"] += 1
            self.url_stats[result.url]["times"].append(result.response_time)
        else:
            self.url_stats[result.url]["failed"] += 1
    
    def get_elapsed(self) -> float:
        return time.time() - self.start_time
    
    def get_rps(self) -> float:
        elapsed = self.get_elapsed()
        return self.completed / elapsed if elapsed > 0 else 0
    
    def get_error_rate(self) -> float:
        return (self.failed / self.completed * 100) if self.completed > 0 else 0
    
    def create_bar(self, value: float, max_value: float, width: int = 20, 
                   char: str = "█", empty: str = "░") -> str:
        if max_value == 0:
            filled = 0
        else:
            filled = int((value / max_value) * width)
        return char * filled + empty * (width - filled)
    
    def create_sparkline(self, values: list, width: int = 20) -> str:
        if not values:
            return "─" * width
        
        chars = "▁▂▃▄▅▆▇█"
        min_val = min(values)
        max_val = max(values)
        
        if max_val == min_val:
            return chars[3] * min(len(values), width)
        
        # Sample values to fit width
        if len(values) > width:
            step = len(values) / width
            sampled = [values[int(i * step)] for i in range(width)]
        else:
            sampled = values
        
        result = ""
        for v in sampled:
            idx = int((v - min_val) / (max_val - min_val) * (len(chars) - 1))
            result += chars[idx]
        
        return result
    
    def create_histogram(self, values: list, bins: int = 10, width: int = 40) -> list[str]:
        if not values:
            return ["No data"]
        
        min_val = min(values)
        max_val = max(values)
        
        if max_val == min_val:
            return [f"{min_val:.0f}ms: {'█' * width} ({len(values)})"]
        
        bin_width = (max_val - min_val) / bins
        histogram = [0] * bins
        
        for v in values:
            idx = min(int((v - min_val) / bin_width), bins - 1)
            histogram[idx] += 1
        
        max_count = max(histogram)
        lines = []
        
        for i, count in enumerate(histogram):
            low = min_val + i * bin_width
            high = low + bin_width
            bar_len = int((count / max_count) * width) if max_count > 0 else 0
            bar = "█" * bar_len
            lines.append(f"  {low*1000:6.0f}-{high*1000:6.0f}ms │{bar} ({count})")
        
        return lines
    
    def render(self):
        """Render the dashboard to terminal."""
        if not self.running:
            return
            
        now = time.time()
        if now - self.last_update < 0.1:  # Limit refresh rate
            return
        self.last_update = now
        
        elapsed = self.get_elapsed()
        rps = self.get_rps()
        error_rate = self.get_error_rate()
        
        # Record time series data
        self.rps_history.append(rps)
        
        # Calculate percentiles
        times_list = list(self.response_times)
        if times_list:
            sorted_times = sorted(times_list)
            avg_time = statistics.mean(times_list)
            p50 = sorted_times[len(sorted_times) // 2]
            p95 = sorted_times[int(len(sorted_times) * 0.95)] if len(sorted_times) >= 20 else sorted_times[-1]
            p99 = sorted_times[int(len(sorted_times) * 0.99)] if len(sorted_times) >= 100 else sorted_times[-1]
        else:
            avg_time = p50 = p95 = p99 = 0
        
        # Clear screen and move cursor to top
        print("\033[2J\033[H", end="")
        
        # Header
        print(f"{Colors.BOLD}{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════════════╗{Colors.RESET}")
        print(f"{Colors.BOLD}{Colors.CYAN}║{Colors.RESET}              {Colors.BOLD}⚡ ULTIMATE LOAD TESTER - LIVE DASHBOARD ⚡{Colors.RESET}              {Colors.BOLD}{Colors.CYAN}║{Colors.RESET}")
        print(f"{Colors.BOLD}{Colors.CYAN}╚══════════════════════════════════════════════════════════════════════════════╝{Colors.RESET}")
        
        # Progress
        if self.config.duration:
            progress = min(elapsed / self.config.duration, 1.0)
            progress_label = f"Time: {elapsed:.0f}s / {self.config.duration}s"
        else:
            progress = self.completed / self.config.total_requests if self.config.total_requests > 0 else 0
            progress_label = f"Requests: {self.completed} / {self.config.total_requests}"
        
        progress_bar = self.create_bar(progress, 1.0, 50)
        print(f"\n  {Colors.BOLD}Progress:{Colors.RESET} [{Colors.GREEN}{progress_bar}{Colors.RESET}] {progress*100:.1f}%")
        print(f"  {progress_label}")
        
        # Main stats
        print(f"\n  {Colors.BOLD}╭─────────────────────── LIVE STATS ───────────────────────╮{Colors.RESET}")
        print(f"  │  {Colors.GREEN}✓ Successful:{Colors.RESET}  {self.successful:<10} {Colors.RED}✗ Failed:{Colors.RESET}  {self.failed:<10}     │")
        print(f"  │  {Colors.CYAN}↻ RPS:{Colors.RESET}          {rps:<10.1f} {Colors.YELLOW}⚠ Error Rate:{Colors.RESET} {error_rate:<6.1f}%      │")
        print(f"  │  {Colors.BLUE}⏱ Elapsed:{Colors.RESET}      {elapsed:<10.1f}s{Colors.DIM}Active:{Colors.RESET}       {self.active_connections:<10}   │")
        print(f"  {Colors.BOLD}╰───────────────────────────────────────────────────────────╯{Colors.RESET}")
        
        # Response times
        print(f"\n  {Colors.BOLD}╭─────────────────── RESPONSE TIMES ───────────────────────╮{Colors.RESET}")
        print(f"  │  Avg: {Colors.CYAN}{avg_time*1000:>7.1f}ms{Colors.RESET}   P50: {Colors.GREEN}{p50*1000:>7.1f}ms{Colors.RESET}                       │")
        print(f"  │  P95: {Colors.YELLOW}{p95*1000:>7.1f}ms{Colors.RESET}   P99: {Colors.RED}{p99*1000:>7.1f}ms{Colors.RESET}                       │")
        print(f"  {Colors.BOLD}╰───────────────────────────────────────────────────────────╯{Colors.RESET}")
        
        # RPS Sparkline
        rps_list = list(self.rps_history)
        if rps_list:
            sparkline = self.create_sparkline(rps_list, 50)
            max_rps = max(rps_list)
            print(f"\n  {Colors.BOLD}RPS Trend:{Colors.RESET} [{Colors.CYAN}{sparkline}{Colors.RESET}] max:{max_rps:.0f}")
        
        # Response time sparkline
        if times_list:
            times_ms = [t * 1000 for t in times_list[-50:]]
            sparkline = self.create_sparkline(times_ms, 50)
            print(f"  {Colors.BOLD}Latency:  {Colors.RESET} [{Colors.YELLOW}{sparkline}{Colors.RESET}] max:{max(times_ms):.0f}ms")
        
        # Status codes
        if self.status_codes:
            print(f"\n  {Colors.BOLD}Status Codes:{Colors.RESET}")
            codes_str = "  "
            for code, count in sorted(self.status_codes.items()):
                color = Colors.GREEN if 200 <= code < 300 else Colors.YELLOW if 300 <= code < 400 else Colors.RED
                codes_str += f"{color}{code}{Colors.RESET}:{count}  "
            print(codes_str)
        
        # Errors (if any)
        if self.errors:
            print(f"\n  {Colors.BOLD}{Colors.RED}Errors:{Colors.RESET}")
            for error, count in list(self.errors.items())[:3]:
                print(f"    {Colors.RED}•{Colors.RESET} {error[:50]}: {count}")
        
        # Footer
        print(f"\n  {Colors.DIM}Press Ctrl+C to stop...{Colors.RESET}")
    
    def stop(self):
        self.running = False


class ReportGenerator:
    """Generate test reports in various formats."""
    
    def __init__(self, config: TestConfig, dashboard: LiveDashboard, results: list[RequestResult]):
        self.config = config
        self.dashboard = dashboard
        self.results = results
        self.stats = self.calculate_stats()
    
    def calculate_stats(self) -> dict:
        """Calculate comprehensive statistics."""
        successful = [r for r in self.results if r.success]
        failed = [r for r in self.results if not r.success]
        response_times = [r.response_time for r in successful]
        
        stats = {
            "summary": {
                "total_requests": len(self.results),
                "successful": len(successful),
                "failed": len(failed),
                "success_rate": (len(successful) / len(self.results) * 100) if self.results else 0,
                "total_time": self.dashboard.get_elapsed(),
                "requests_per_second": self.dashboard.get_rps(),
                "data_transferred": sum(r.size for r in successful),
            },
            "timing": {},
            "status_codes": self.dashboard.status_codes,
            "errors": self.dashboard.errors,
            "url_stats": {},
            "validation": {
                "total_validated": sum(1 for r in self.results if r.validation_passed is not None),
                "passed": sum(1 for r in self.results if r.validation_passed),
                "failed": sum(1 for r in self.results if not r.validation_passed),
            }
        }
        
        if response_times:
            sorted_times = sorted(response_times)
            n = len(sorted_times)
            stats["timing"] = {
                "min": min(response_times),
                "max": max(response_times),
                "mean": statistics.mean(response_times),
                "median": statistics.median(response_times),
                "stdev": statistics.stdev(response_times) if n > 1 else 0,
                "p10": sorted_times[int(n * 0.10)] if n >= 10 else sorted_times[0],
                "p25": sorted_times[int(n * 0.25)] if n >= 4 else sorted_times[0],
                "p50": sorted_times[int(n * 0.50)],
                "p75": sorted_times[int(n * 0.75)] if n >= 4 else sorted_times[-1],
                "p90": sorted_times[int(n * 0.90)] if n >= 10 else sorted_times[-1],
                "p95": sorted_times[int(n * 0.95)] if n >= 20 else sorted_times[-1],
                "p99": sorted_times[int(n * 0.99)] if n >= 100 else sorted_times[-1],
            }
        
        # Per-URL statistics
        for url, data in self.dashboard.url_stats.items():
            if data["times"]:
                sorted_url_times = sorted(data["times"])
                stats["url_stats"][url] = {
                    "successful": data["success"],
                    "failed": data["failed"],
                    "avg_time": statistics.mean(data["times"]),
                    "min_time": min(data["times"]),
                    "max_time": max(data["times"]),
                    "p95_time": sorted_url_times[int(len(sorted_url_times) * 0.95)] if len(sorted_url_times) >= 20 else sorted_url_times[-1],
                }
        
        return stats
    
    def print_terminal_report(self):
        """Print formatted report to terminal."""
        s = self.stats
        
        print(f"\n{Colors.BOLD}{Colors.CYAN}{'═' * 78}{Colors.RESET}")
        print(f"{Colors.BOLD}{Colors.CYAN}                           LOAD TEST REPORT{Colors.RESET}")
        print(f"{Colors.BOLD}{Colors.CYAN}{'═' * 78}{Colors.RESET}")
        
        # Test configuration
        print(f"\n{Colors.BOLD}TEST CONFIGURATION{Colors.RESET}")
        print(f"{'─' * 40}")
        print(f"  Mode:             {self.config.mode.value}")
        print(f"  Concurrency:      {self.config.concurrency}")
        print(f"  Timeout:          {self.config.timeout}s")
        if self.config.rate_limit:
            print(f"  Rate Limit:       {self.config.rate_limit} req/s")
        
        # Summary
        print(f"\n{Colors.BOLD}SUMMARY{Colors.RESET}")
        print(f"{'─' * 40}")
        print(f"  Total Requests:   {s['summary']['total_requests']}")
        print(f"  {Colors.GREEN}Successful:{Colors.RESET}        {s['summary']['successful']}")
        print(f"  {Colors.RED}Failed:{Colors.RESET}            {s['summary']['failed']}")
        print(f"  Success Rate:     {s['summary']['success_rate']:.2f}%")
        print(f"  Total Time:       {s['summary']['total_time']:.2f}s")
        print(f"  Throughput:       {s['summary']['requests_per_second']:.2f} req/s")
        print(f"  Data Transferred: {s['summary']['data_transferred'] / 1024:.2f} KB")
        
        # Timing
        if s["timing"]:
            print(f"\n{Colors.BOLD}RESPONSE TIMES{Colors.RESET}")
            print(f"{'─' * 40}")
            t = s["timing"]
            print(f"  Min:              {t['min']*1000:.2f}ms")
            print(f"  Max:              {t['max']*1000:.2f}ms")
            print(f"  Mean:             {t['mean']*1000:.2f}ms")
            print(f"  Median:           {t['median']*1000:.2f}ms")
            print(f"  Std Dev:          {t['stdev']*1000:.2f}ms")
            print(f"\n  {Colors.BOLD}Percentiles:{Colors.RESET}")
            print(f"    P10:  {t['p10']*1000:>8.2f}ms    P75:  {t['p75']*1000:>8.2f}ms")
            print(f"    P25:  {t['p25']*1000:>8.2f}ms    P90:  {t['p90']*1000:>8.2f}ms")
            print(f"    P50:  {t['p50']*1000:>8.2f}ms    P95:  {t['p95']*1000:>8.2f}ms")
            print(f"                           P99:  {t['p99']*1000:>8.2f}ms")
        
        # Histogram
        response_times = [r.response_time for r in self.results if r.success]
        if response_times:
            print(f"\n{Colors.BOLD}RESPONSE TIME DISTRIBUTION{Colors.RESET}")
            print(f"{'─' * 40}")
            histogram_lines = self.dashboard.create_histogram(response_times, bins=8, width=30)
            for line in histogram_lines:
                print(line)
        
        # Status codes
        if s["status_codes"]:
            print(f"\n{Colors.BOLD}STATUS CODES{Colors.RESET}")
            print(f"{'─' * 40}")
            for code, count in sorted(s["status_codes"].items()):
                pct = count / s['summary']['total_requests'] * 100
                bar = self.dashboard.create_bar(pct, 100, 20)
                color = Colors.GREEN if 200 <= code < 300 else Colors.YELLOW if 300 <= code < 400 else Colors.RED
                print(f"  {color}{code}{Colors.RESET}: {bar} {count:>6} ({pct:.1f}%)")
        
        # Errors
        if s["errors"]:
            print(f"\n{Colors.BOLD}{Colors.RED}ERRORS{Colors.RESET}")
            print(f"{'─' * 40}")
            for error, count in sorted(s["errors"].items(), key=lambda x: -x[1]):
                print(f"  {Colors.RED}•{Colors.RESET} {error}: {count}")
        
        # Per-URL stats
        if len(s["url_stats"]) > 1:
            print(f"\n{Colors.BOLD}PER-URL STATISTICS{Colors.RESET}")
            print(f"{'─' * 40}")
            for url, data in s["url_stats"].items():
                path = urlparse(url).path or "/"
                print(f"\n  {Colors.CYAN}{path}{Colors.RESET}")
                print(f"    Success: {data['successful']}  Failed: {data['failed']}")
                print(f"    Avg: {data['avg_time']*1000:.1f}ms  P95: {data['p95_time']*1000:.1f}ms")
        
        # Validation results
        if self.config.validation:
            print(f"\n{Colors.BOLD}VALIDATION{Colors.RESET}")
            print(f"{'─' * 40}")
            print(f"  Passed: {s['validation']['passed']}")
            print(f"  Failed: {s['validation']['failed']}")
        
        print(f"\n{Colors.BOLD}{Colors.CYAN}{'═' * 78}{Colors.RESET}\n")
    
    def export_json(self, filepath: str):
        """Export results to JSON file."""
        data = {
            "test_info": {
                "timestamp": datetime.now().isoformat(),
                "mode": self.config.mode.value,
                "concurrency": self.config.concurrency,
                "total_requests": self.config.total_requests,
            },
            "statistics": self.stats,
            "requests": [
                {
                    "url": r.url,
                    "method": r.method,
                    "status_code": r.status_code,
                    "response_time": r.response_time,
                    "success": r.success,
                    "size": r.size,
                    "error": r.error,
                    "timestamp": r.timestamp,
                }
                for r in self.results
            ]
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"{Colors.GREEN}✓ JSON report saved to: {filepath}{Colors.RESET}")
    
    def export_csv(self, filepath: str):
        """Export results to CSV file."""
        with open(filepath, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['timestamp', 'url', 'method', 'status_code', 'response_time_ms', 
                           'success', 'size_bytes', 'error'])
            
            for r in self.results:
                writer.writerow([
                    r.timestamp, r.url, r.method, r.status_code,
                    r.response_time * 1000, r.success, r.size, r.error
                ])
        
        print(f"{Colors.GREEN}✓ CSV report saved to: {filepath}{Colors.RESET}")
    
    def export_html(self, filepath: str):
        """Export results to HTML report."""
        s = self.stats
        
        # Generate histogram data for chart
        response_times = [r.response_time * 1000 for r in self.results if r.success]
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Load Test Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
               background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #eee; 
               min-height: 100vh; padding: 40px; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        h1 {{ text-align: center; font-size: 2.5em; margin-bottom: 40px; 
             background: linear-gradient(90deg, #00d4ff, #7c3aed); -webkit-background-clip: text; 
             -webkit-text-fill-color: transparent; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 30px; }}
        .card {{ background: rgba(255,255,255,0.05); border-radius: 16px; padding: 24px; 
                border: 1px solid rgba(255,255,255,0.1); backdrop-filter: blur(10px); }}
        .card h3 {{ color: #00d4ff; margin-bottom: 16px; font-size: 0.9em; text-transform: uppercase; letter-spacing: 1px; }}
        .stat {{ font-size: 2.5em; font-weight: 700; }}
        .stat.green {{ color: #22c55e; }}
        .stat.red {{ color: #ef4444; }}
        .stat.blue {{ color: #3b82f6; }}
        .stat.yellow {{ color: #eab308; }}
        .label {{ color: #888; font-size: 0.9em; margin-top: 4px; }}
        .chart-container {{ background: rgba(255,255,255,0.05); border-radius: 16px; padding: 24px; 
                          margin-bottom: 30px; border: 1px solid rgba(255,255,255,0.1); }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.1); }}
        th {{ color: #00d4ff; font-weight: 600; }}
        .bar {{ height: 8px; background: #3b82f6; border-radius: 4px; }}
        .timestamp {{ text-align: center; color: #666; margin-top: 40px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>⚡ Load Test Report</h1>
        
        <div class="grid">
            <div class="card">
                <h3>Total Requests</h3>
                <div class="stat blue">{s['summary']['total_requests']:,}</div>
                <div class="label">requests sent</div>
            </div>
            <div class="card">
                <h3>Success Rate</h3>
                <div class="stat green">{s['summary']['success_rate']:.1f}%</div>
                <div class="label">{s['summary']['successful']:,} successful</div>
            </div>
            <div class="card">
                <h3>Failed</h3>
                <div class="stat red">{s['summary']['failed']:,}</div>
                <div class="label">requests failed</div>
            </div>
            <div class="card">
                <h3>Throughput</h3>
                <div class="stat yellow">{s['summary']['requests_per_second']:.1f}</div>
                <div class="label">requests/second</div>
            </div>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3>Mean Response Time</h3>
                <div class="stat">{s['timing'].get('mean', 0)*1000:.1f}<span style="font-size:0.4em">ms</span></div>
            </div>
            <div class="card">
                <h3>P95 Response Time</h3>
                <div class="stat">{s['timing'].get('p95', 0)*1000:.1f}<span style="font-size:0.4em">ms</span></div>
            </div>
            <div class="card">
                <h3>P99 Response Time</h3>
                <div class="stat">{s['timing'].get('p99', 0)*1000:.1f}<span style="font-size:0.4em">ms</span></div>
            </div>
            <div class="card">
                <h3>Data Transferred</h3>
                <div class="stat">{s['summary']['data_transferred']/1024:.1f}<span style="font-size:0.4em">KB</span></div>
            </div>
        </div>
        
        <div class="chart-container">
            <h3 style="color: #00d4ff; margin-bottom: 20px;">Response Time Distribution</h3>
            <canvas id="histogramChart" height="100"></canvas>
        </div>
        
        <div class="chart-container">
            <h3 style="color: #00d4ff; margin-bottom: 20px;">Status Codes</h3>
            <table>
                <tr><th>Code</th><th>Count</th><th>Percentage</th><th></th></tr>
                {''.join(f'<tr><td>{code}</td><td>{count}</td><td>{count/s["summary"]["total_requests"]*100:.1f}%</td><td><div class="bar" style="width:{count/s["summary"]["total_requests"]*100}%"></div></td></tr>' for code, count in sorted(s['status_codes'].items()))}
            </table>
        </div>
        
        <div class="timestamp">Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
    </div>
    
    <script>
        const times = {json.dumps(response_times[:1000])};
        const bins = 20;
        const min = Math.min(...times);
        const max = Math.max(...times);
        const binWidth = (max - min) / bins;
        const histogram = Array(bins).fill(0);
        times.forEach(t => {{
            const idx = Math.min(Math.floor((t - min) / binWidth), bins - 1);
            histogram[idx]++;
        }});
        const labels = histogram.map((_, i) => Math.round(min + i * binWidth) + 'ms');
        
        new Chart(document.getElementById('histogramChart'), {{
            type: 'bar',
            data: {{
                labels: labels,
                datasets: [{{ data: histogram, backgroundColor: 'rgba(59, 130, 246, 0.8)', borderRadius: 4 }}]
            }},
            options: {{
                plugins: {{ legend: {{ display: false }} }},
                scales: {{
                    y: {{ grid: {{ color: 'rgba(255,255,255,0.1)' }}, ticks: {{ color: '#888' }} }},
                    x: {{ grid: {{ display: false }}, ticks: {{ color: '#888', maxRotation: 45 }} }}
                }}
            }}
        }});
    </script>
</body>
</html>"""
        
        with open(filepath, 'w') as f:
            f.write(html)
        
        print(f"{Colors.GREEN}✓ HTML report saved to: {filepath}{Colors.RESET}")


class LoadTester:
    """Main load testing engine."""
    
    def __init__(self, config: TestConfig):
        self.config = config
        self.results: list[RequestResult] = []
        self.dashboard = LiveDashboard(config)
        self.running = True
        self.start_time = 0
        self.semaphore: Optional[asyncio.Semaphore] = None
        self.rate_limiter: Optional[asyncio.Semaphore] = None
        self.session: Optional[aiohttp.ClientSession] = None
    
    def get_request_config(self) -> RequestConfig:
        """Get a request config based on weights."""
        if len(self.config.requests) == 1:
            return self.config.requests[0]
        
        total_weight = sum(r.weight for r in self.config.requests)
        rand = random.random() * total_weight
        
        cumulative = 0
        for req in self.config.requests:
            cumulative += req.weight
            if rand <= cumulative:
                return req
        
        return self.config.requests[-1]
    
    async def send_request(self, req_config: RequestConfig) -> RequestResult:
        """Send a single HTTP request."""
        start_time = time.perf_counter()
        timestamp = time.time()
        
        try:
            # Prepare request kwargs
            kwargs = {
                "timeout": aiohttp.ClientTimeout(total=self.config.timeout),
                "headers": req_config.headers,
                "cookies": req_config.cookies,
                "allow_redirects": self.config.follow_redirects,
                "max_redirects": self.config.max_redirects,
                "ssl": self.config.verify_ssl,
            }
            
            if self.config.proxy:
                kwargs["proxy"] = self.config.proxy
            
            # Handle request body
            if req_config.json_body:
                kwargs["json"] = req_config.json_body
            elif req_config.form_data:
                kwargs["data"] = req_config.form_data
            elif req_config.body:
                kwargs["data"] = req_config.body
            
            async with self.session.request(
                req_config.method.value,
                req_config.url,
                **kwargs
            ) as response:
                content = await response.read()
                response_time = time.perf_counter() - start_time
                
                result = RequestResult(
                    url=req_config.url,
                    method=req_config.method.value,
                    success=True,
                    status_code=response.status,
                    response_time=response_time,
                    timestamp=timestamp,
                    size=len(content),
                    response_headers=dict(response.headers) if self.config.save_responses else None,
                    response_body=content.decode('utf-8', errors='ignore') if self.config.save_responses else None,
                )
                
                # Validate response
                if self.config.validation:
                    passed, errors = ResponseValidator.validate(result, self.config.validation)
                    result.validation_passed = passed
                    result.validation_errors = errors
                
                return result
                
        except asyncio.TimeoutError:
            return RequestResult(
                url=req_config.url,
                method=req_config.method.value,
                success=False,
                status_code=None,
                response_time=time.perf_counter() - start_time,
                timestamp=timestamp,
                error="Timeout"
            )
        except aiohttp.ClientError as e:
            return RequestResult(
                url=req_config.url,
                method=req_config.method.value,
                success=False,
                status_code=None,
                response_time=time.perf_counter() - start_time,
                timestamp=timestamp,
                error=str(e)[:100]
            )
        except Exception as e:
            return RequestResult(
                url=req_config.url,
                method=req_config.method.value,
                success=False,
                status_code=None,
                response_time=time.perf_counter() - start_time,
                timestamp=timestamp,
                error=str(e)[:100]
            )
    
    async def worker(self):
        """Worker coroutine that sends requests."""
        while self.running:
            # Check termination conditions
            if self.config.duration:
                if time.time() - self.start_time >= self.config.duration:
                    break
            elif self.dashboard.completed >= self.config.total_requests:
                break
            
            async with self.semaphore:
                if not self.running:
                    break
                
                self.dashboard.active_connections += 1
                
                # Rate limiting
                if self.rate_limiter:
                    async with self.rate_limiter:
                        pass
                
                # Think time
                if self.config.think_time[1] > 0:
                    delay = random.uniform(*self.config.think_time)
                    await asyncio.sleep(delay)
                
                # Send request
                req_config = self.get_request_config()
                result = await self.send_request(req_config)
                
                self.results.append(result)
                self.dashboard.add_result(result)
                self.dashboard.active_connections -= 1
                
                if self.config.verbose:
                    status = f"{Colors.GREEN}✓{Colors.RESET}" if result.success else f"{Colors.RED}✗{Colors.RESET}"
                    print(f"{status} {result.method} {result.url} - {result.status_code or result.error} ({result.response_time*1000:.0f}ms)")
    
    async def run_warm_up(self):
        """Run warm-up requests."""
        if self.config.warm_up_requests <= 0:
            return
        
        print(f"{Colors.YELLOW}Running {self.config.warm_up_requests} warm-up requests...{Colors.RESET}")
        
        for _ in range(self.config.warm_up_requests):
            req_config = self.get_request_config()
            await self.send_request(req_config)
        
        print(f"{Colors.GREEN}Warm-up complete!{Colors.RESET}\n")
    
    async def run_sustained(self):
        """Run sustained load test."""
        workers = [asyncio.create_task(self.worker()) for _ in range(self.config.concurrency * 2)]
        
        # Dashboard update loop
        while self.running and any(not w.done() for w in workers):
            self.dashboard.render()
            await asyncio.sleep(0.1)
            
            # Check completion
            if self.config.duration:
                if time.time() - self.start_time >= self.config.duration:
                    self.running = False
            elif self.dashboard.completed >= self.config.total_requests:
                self.running = False
        
        # Cancel remaining workers
        for w in workers:
            w.cancel()
        
        await asyncio.gather(*workers, return_exceptions=True)
    
    async def run_ramp_up(self):
        """Run ramp-up load test."""
        step_duration = self.config.ramp_up_time / self.config.ramp_up_steps
        step_concurrency = self.config.concurrency / self.config.ramp_up_steps
        
        workers = []
        
        for step in range(self.config.ramp_up_steps):
            if not self.running:
                break
            
            current_concurrency = int(step_concurrency * (step + 1))
            self.semaphore = asyncio.Semaphore(current_concurrency)
            
            # Add new workers
            new_workers = [asyncio.create_task(self.worker()) 
                         for _ in range(int(step_concurrency))]
            workers.extend(new_workers)
            
            # Run for step duration
            step_start = time.time()
            while time.time() - step_start < step_duration and self.running:
                self.dashboard.render()
                await asyncio.sleep(0.1)
        
        # Continue with full load
        while self.running:
            self.dashboard.render()
            await asyncio.sleep(0.1)
            
            if self.config.duration:
                if time.time() - self.start_time >= self.config.duration:
                    self.running = False
            elif self.dashboard.completed >= self.config.total_requests:
                self.running = False
        
        for w in workers:
            w.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
    
    async def run(self):
        """Run the load test."""
        self.start_time = time.time()
        self.semaphore = asyncio.Semaphore(self.config.concurrency)
        
        # Setup rate limiter if configured
        if self.config.rate_limit:
            self.rate_limiter = asyncio.Semaphore(int(self.config.rate_limit))
            asyncio.create_task(self._release_rate_limiter())
        
        # Create session
        connector = aiohttp.TCPConnector(
            limit=self.config.concurrency,
            limit_per_host=self.config.concurrency,
            ssl=self.config.verify_ssl
        )
        
        self.session = aiohttp.ClientSession(connector=connector)
        
        try:
            # Run warm-up
            await self.run_warm_up()
            
            # Run test based on mode
            if self.config.mode == TestMode.RAMP_UP:
                await self.run_ramp_up()
            else:
                await self.run_sustained()
            
        finally:
            await self.session.close()
            self.dashboard.stop()
    
    async def _release_rate_limiter(self):
        """Release rate limiter tokens periodically."""
        while self.running:
            await asyncio.sleep(1)
            for _ in range(int(self.config.rate_limit)):
                try:
                    self.rate_limiter.release()
                except ValueError:
                    pass
    
    def stop(self):
        """Stop the test."""
        self.running = False
        self.dashboard.stop()


def load_config_file(filepath: str) -> dict:
    """Load configuration from JSON or YAML file."""
    with open(filepath, 'r') as f:
        if filepath.endswith('.json'):
            return json.load(f)
        elif filepath.endswith(('.yml', '.yaml')):
            try:
                import yaml
                return yaml.safe_load(f)
            except ImportError:
                print(f"{Colors.RED}PyYAML not installed. Install with: pip install pyyaml{Colors.RESET}")
                sys.exit(1)
    return {}


def interactive_setup() -> TestConfig:
    """Interactive configuration setup."""
    print(f"\n{Colors.BOLD}{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════════════╗{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}║{Colors.RESET}                    {Colors.BOLD}⚡ ULTIMATE LOAD TESTER v2.0 ⚡{Colors.RESET}                        {Colors.BOLD}{Colors.CYAN}║{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}║{Colors.RESET}                  {Colors.DIM}Professional HTTP Load Testing Tool{Colors.RESET}                      {Colors.BOLD}{Colors.CYAN}║{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}║{Colors.RESET}                    {Colors.RED}⚠  For your own sites only! ⚠{Colors.RESET}                         {Colors.BOLD}{Colors.CYAN}║{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}╚══════════════════════════════════════════════════════════════════════════════╝{Colors.RESET}")
    
    # URL input
    print(f"\n{Colors.BOLD}1. TARGET URL(s){Colors.RESET}")
    print(f"   {Colors.DIM}Enter one or more URLs (comma-separated for multiple){Colors.RESET}")
    
    urls_input = input(f"\n   {Colors.CYAN}➜{Colors.RESET} URL(s): ").strip()
    urls = [u.strip() for u in urls_input.split(',')]
    
    requests = []
    for url in urls:
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        requests.append(RequestConfig(url=url))
    
    # Method
    print(f"\n{Colors.BOLD}2. HTTP METHOD{Colors.RESET}")
    method_input = input(f"   {Colors.CYAN}➜{Colors.RESET} Method [GET]: ").strip().upper() or "GET"
    
    try:
        method = HttpMethod[method_input]
        for req in requests:
            req.method = method
    except KeyError:
        print(f"   {Colors.YELLOW}Invalid method, using GET{Colors.RESET}")
    
    # Test mode
    print(f"\n{Colors.BOLD}3. TEST MODE{Colors.RESET}")
    print(f"   {Colors.DIM}1. sustained  - Constant load{Colors.RESET}")
    print(f"   {Colors.DIM}2. ramp_up    - Gradually increase load{Colors.RESET}")
    print(f"   {Colors.DIM}3. spike      - Sudden burst of traffic{Colors.RESET}")
    print(f"   {Colors.DIM}4. stress     - Increase until failure{Colors.RESET}")
    
    mode_input = input(f"   {Colors.CYAN}➜{Colors.RESET} Mode [1]: ").strip() or "1"
    mode_map = {"1": TestMode.SUSTAINED, "2": TestMode.RAMP_UP, "3": TestMode.SPIKE, "4": TestMode.STRESS,
                "sustained": TestMode.SUSTAINED, "ramp_up": TestMode.RAMP_UP, 
                "spike": TestMode.SPIKE, "stress": TestMode.STRESS}
    mode = mode_map.get(mode_input.lower(), TestMode.SUSTAINED)
    
    # Duration or requests
    print(f"\n{Colors.BOLD}4. TEST DURATION{Colors.RESET}")
    print(f"   {Colors.DIM}Enter number of requests OR duration in seconds (e.g., '100' or '30s'){Colors.RESET}")
    
    duration_input = input(f"   {Colors.CYAN}➜{Colors.RESET} Duration [100 requests]: ").strip() or "100"
    
    duration = None
    total_requests = 100
    
    if duration_input.endswith('s'):
        duration = int(duration_input[:-1])
        total_requests = 0
    else:
        total_requests = int(duration_input)
    
    # Concurrency
    print(f"\n{Colors.BOLD}5. CONCURRENCY{Colors.RESET}")
    concurrency = int(input(f"   {Colors.CYAN}➜{Colors.RESET} Concurrent connections [10]: ").strip() or "10")
    
    # Rate limit
    print(f"\n{Colors.BOLD}6. RATE LIMIT{Colors.RESET}")
    rate_input = input(f"   {Colors.CYAN}➜{Colors.RESET} Max requests/second (empty for unlimited): ").strip()
    rate_limit = float(rate_input) if rate_input else None
    
    # Timeout
    print(f"\n{Colors.BOLD}7. TIMEOUT{Colors.RESET}")
    timeout = int(input(f"   {Colors.CYAN}➜{Colors.RESET} Request timeout in seconds [30]: ").strip() or "30")
    
    # Headers
    print(f"\n{Colors.BOLD}8. CUSTOM HEADERS{Colors.RESET}")
    print(f"   {Colors.DIM}Format: Header-Name: value (one per line, empty to finish){Colors.RESET}")
    
    headers = {}
    while True:
        header = input(f"   {Colors.CYAN}➜{Colors.RESET} ").strip()
        if not header:
            break
        if ':' in header:
            key, value = header.split(':', 1)
            headers[key.strip()] = value.strip()
    
    for req in requests:
        req.headers = headers
    
    # Validation
    print(f"\n{Colors.BOLD}9. RESPONSE VALIDATION{Colors.RESET}")
    validation = {}
    
    status_codes = input(f"   {Colors.CYAN}➜{Colors.RESET} Expected status codes (comma-separated, e.g., '200,201') [any]: ").strip()
    if status_codes:
        validation["status_codes"] = [int(c.strip()) for c in status_codes.split(',')]
    
    max_time = input(f"   {Colors.CYAN}➜{Colors.RESET} Max response time in seconds [any]: ").strip()
    if max_time:
        validation["max_response_time"] = float(max_time)
    
    # Export options
    print(f"\n{Colors.BOLD}10. EXPORT OPTIONS{Colors.RESET}")
    export_json = input(f"   {Colors.CYAN}➜{Colors.RESET} Export JSON report? (y/n) [n]: ").strip().lower() == 'y'
    export_csv = input(f"   {Colors.CYAN}➜{Colors.RESET} Export CSV data? (y/n) [n]: ").strip().lower() == 'y'
    export_html = input(f"   {Colors.CYAN}➜{Colors.RESET} Export HTML report? (y/n) [n]: ").strip().lower() == 'y'
    
    # Confirmation
    print(f"\n{Colors.BOLD}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.BOLD}CONFIGURATION SUMMARY{Colors.RESET}")
    print(f"{'─' * 60}")
    print(f"  URLs:         {', '.join(r.url for r in requests)}")
    print(f"  Method:       {method.value}")
    print(f"  Mode:         {mode.value}")
    if duration:
        print(f"  Duration:     {duration} seconds")
    else:
        print(f"  Requests:     {total_requests}")
    print(f"  Concurrency:  {concurrency}")
    if rate_limit:
        print(f"  Rate Limit:   {rate_limit} req/s")
    print(f"  Timeout:      {timeout}s")
    if headers:
        print(f"  Headers:      {len(headers)} custom")
    if validation:
        print(f"  Validation:   {len(validation)} rules")
    print(f"{'─' * 60}")
    
    confirm = input(f"\n{Colors.BOLD}Start test? (yes/no):{Colors.RESET} ").strip().lower()
    if confirm != 'yes':
        print(f"{Colors.YELLOW}Test cancelled.{Colors.RESET}")
        sys.exit(0)
    
    return TestConfig(
        requests=requests,
        total_requests=total_requests,
        concurrency=concurrency,
        duration=duration,
        mode=mode,
        rate_limit=rate_limit,
        timeout=timeout,
        validation=validation,
    ), export_json, export_csv, export_html


async def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description='Ultimate Load Tester - Professional HTTP Load Testing Tool')
    parser.add_argument('--config', '-c', help='Path to config file (JSON/YAML)')
    parser.add_argument('--url', '-u', help='Target URL')
    parser.add_argument('--requests', '-n', type=int, default=100, help='Number of requests')
    parser.add_argument('--concurrency', '-C', type=int, default=10, help='Concurrent connections')
    parser.add_argument('--duration', '-d', type=int, help='Test duration in seconds')
    parser.add_argument('--rate', '-r', type=float, help='Rate limit (requests/second)')
    parser.add_argument('--method', '-m', default='GET', help='HTTP method')
    parser.add_argument('--timeout', '-t', type=int, default=30, help='Request timeout')
    parser.add_argument('--json', action='store_true', help='Export JSON report')
    parser.add_argument('--csv', action='store_true', help='Export CSV data')
    parser.add_argument('--html', action='store_true', help='Export HTML report')
    parser.add_argument('--no-color', action='store_true', help='Disable colored output')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    if args.no_color:
        Colors.disable()
    
    export_json = args.json
    export_csv = args.csv
    export_html = args.html
    
    # Determine configuration source
    if args.config:
        # Load from config file
        config_data = load_config_file(args.config)
        requests = [RequestConfig(**r) for r in config_data.get('requests', [])]
        config = TestConfig(
            requests=requests,
            total_requests=config_data.get('total_requests', 100),
            concurrency=config_data.get('concurrency', 10),
            duration=config_data.get('duration'),
            mode=TestMode(config_data.get('mode', 'sustained')),
            rate_limit=config_data.get('rate_limit'),
            timeout=config_data.get('timeout', 30),
            validation=config_data.get('validation', {}),
            verbose=args.verbose,
        )
    elif args.url:
        # Use command line arguments
        url = args.url if args.url.startswith(('http://', 'https://')) else 'https://' + args.url
        config = TestConfig(
            requests=[RequestConfig(url=url, method=HttpMethod[args.method.upper()])],
            total_requests=args.requests,
            concurrency=args.concurrency,
            duration=args.duration,
            rate_limit=args.rate,
            timeout=args.timeout,
            verbose=args.verbose,
        )
    else:
        # Interactive mode
        config, export_json, export_csv, export_html = interactive_setup()
    
    # Setup signal handler for graceful shutdown
    tester = LoadTester(config)
    
    def signal_handler(sig, frame):
        print(f"\n{Colors.YELLOW}Stopping test...{Colors.RESET}")
        tester.stop()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    # Run test
    print(f"\n{Colors.GREEN}Starting load test...{Colors.RESET}\n")
    
    try:
        await tester.run()
    except Exception as e:
        print(f"{Colors.RED}Error: {e}{Colors.RESET}")
    
    # Generate report
    report = ReportGenerator(config, tester.dashboard, tester.results)
    report.print_terminal_report()
    
    # Export reports
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    if export_json:
        report.export_json(f'load_test_report_{timestamp}.json')
    
    if export_csv:
        report.export_csv(f'load_test_data_{timestamp}.csv')
    
    if export_html:
        report.export_html(f'load_test_report_{timestamp}.html')


if __name__ == '__main__':
    asyncio.run(main())
