import turtle
import time
import random


screen = turtle.Screen()
screen.bgcolor("black")
screen.tracer(0)  # Turn off automatic updates for speed

def draw_spiral(t, x, y, color):
    """Draw a spiral at the given position with the given color"""
    a = 0
    b = 0
    t.penup()
    t.goto(x, y)
    t.pendown()
    t.pencolor(color)
    while True:
        t.forward(a)
        t.right(b)
        a += 3
        b += 1
        if b == 200:
            break
    screen.update()

# Draw original spiral
main_turtle = turtle.Turtle()
main_turtle.hideturtle()
main_turtle.speed(0)
draw_spiral(main_turtle, 0, 200, "green")
time.sleep(1)

# Move the spiral around
positions = [(100, 150), (-100, 100), (50, 50), (-50, 0), (0, 200)]
for pos in positions:
    main_turtle.clear()
    draw_spiral(main_turtle, pos[0], pos[1], "green")
    time.sleep(0.5)

main_turtle.clear()

# Duplicate the spiral 10 times in random positions with different colors
colors = ["red", "yellow", "cyan", "magenta", "orange", "pink", "lime", "violet", "gold", "white"]
spiral_turtles = []

for i in range(10):
    new_turtle = turtle.Turtle()
    new_turtle.hideturtle()
    new_turtle.speed(0)
    x = random.randint(-250, 250)
    y = random.randint(-150, 250)
    draw_spiral(new_turtle, x, y, colors[i])
    spiral_turtles.append(new_turtle)
    time.sleep(0.3)

# Add the message 10 times
for i in range(10):
    msg_turtle = turtle.Turtle()
    msg_turtle.hideturtle()
    msg_turtle.penup()
    x = random.randint(-300, 300)
    y = random.randint(-300, -100)
    msg_turtle.goto(x, y)
    msg_turtle.color(colors[i])
    msg_turtle.write("Hello, you have been hacked! and also you are an idiot", align="center", font=("Arial", 12, "bold"))
    screen.update()
    time.sleep(0.2)

turtle.exitonclick()
