#!/usr/bin/env python3
import subprocess
import time

def get_size(path):
    try:
        return int(subprocess.check_output(["du", "-ks", path]).decode().split()[0])
    except:
        return 0

DOWNLOAD_PATH = "win7.iso"  # Change to your download or USB mount path
USB_PATH = "Ventoy"           # Optional: monitor USB copy activity
SLEEP_INTERVAL = 20
NO_CHANGE_LIMIT = 3  # Number of intervals with no change before re-enabling suspend

paths = [p for p in [DOWNLOAD_PATH, USB_PATH] if p]  # Only include valid paths

last_sizes = [get_size(p) for p in paths]
no_change_count = 0

# Disable suspend initially
subprocess.run(["gsettings", "set", "org.gnome.settings-daemon.plugins.power", "sleep-inactive-ac-timeout", "0"])

print("Monitoring for download/copy activity...")

while True:
    time.sleep(SLEEP_INTERVAL)
    changed = False

    for i, path in enumerate(paths):
        current_size = get_size(path)
        if current_size > last_sizes[i]:
            changed = True
        last_sizes[i] = current_size

    if changed:
        no_change_count = 0
    else:
        no_change_count += 1

    if no_change_count >= NO_CHANGE_LIMIT:
        # Re-enable suspend after inactivity
        subprocess.run(["gsettings", "set", "org.gnome.settings-daemon.plugins.power", "sleep-inactive-ac-timeout", "600"])  # e.g., 10 minutes
    else:
        # Keep suspend disabled
        subprocess.run(["gsettings", "set", "org.gnome.settings-daemon.plugins.power", "sleep-inactive-ac-timeout", "0"])   
